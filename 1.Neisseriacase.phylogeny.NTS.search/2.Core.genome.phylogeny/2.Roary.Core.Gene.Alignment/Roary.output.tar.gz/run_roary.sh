roary -e --mafft -v -p 16 -n -i 50 -cd 80 *.gff 
